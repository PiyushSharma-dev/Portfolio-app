import React from "react";
const ProjectsPage = ({ data }) => (
  <div className="relative pt-8 pb-16">
    <h3 className="text-xl font-semibold text-gray-800 mb-6 mt-12 text-center">Key Projects</h3>
    <div className="grid grid-cols-2 gap-y-8 mt-4 px-4">
      {data.map((project, index) => (
        <div key={index} className="bg-white rounded-xl p-4 shadow-md text-left w-full">
          <h4 className="font-bold text-gray-900 mb-2">{project.title}</h4>
          <p className="text-sm text-gray-700">{project.details}</p>
        </div>
      ))}
    </div>
  </div>
);
export default ProjectsPage;