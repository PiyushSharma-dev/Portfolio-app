import React, { useState } from "react";
import { User, Briefcase, GraduationCap, MapPin, X } from "lucide-react";
import portfolioData from "./data/portfolioData";
import calculateAge from "./utils/calculateAge";
import HeaderButton from "./components/HeaderButton";
import ProjectsPage from "./pages/ProjectsPage";

const App = () => {
  const [currentPage, setCurrentPage] = useState("aboutMe");
  const age = calculateAge(7, 1990);

  return (
    <div className="min-h-screen bg-gray-900 p-4 flex items-center justify-center">
      <div className="relative w-full max-w-7xl bg-gray-800 rounded-[3rem] p-6 shadow-2xl">
        <button className="absolute top-6 left-6 p-2 rounded-full bg-gray-700 text-gray-300 hover:bg-gray-600">
          <X size={20} />
        </button>
        <div className="flex items-center justify-between pl-16 pr-8 py-10 bg-gray-800">
          <div>
            <p className="text-sm text-gray-400 -mb-1 ml-2">{portfolioData.tagline}</p>
            <h1 className="text-3xl font-semibold text-white ml-2">{portfolioData.name}</h1>
          </div>
          <div className="flex space-x-3">
            <HeaderButton icon={<User size={16} />} text="About Me" isActive={currentPage === "aboutMe"} onClick={() => setCurrentPage("aboutMe")} />
            <HeaderButton icon={<Briefcase size={16} />} text="Experience & Projects" isActive={currentPage === "projects"} onClick={() => setCurrentPage("projects")} />
            <HeaderButton icon={<GraduationCap size={16} />} text="Education" isActive={currentPage === "education"} onClick={() => setCurrentPage("education")} />
            <HeaderButton icon={<MapPin size={16} />} text="Location" isActive={currentPage === "location"} onClick={() => setCurrentPage("location")} />
          </div>
        </div>
        <div className="flex flex-col bg-gray-100 rounded-3xl p-6 shadow-inner min-h-[70vh] mt-6">
          {currentPage === "aboutMe" && <p>{portfolioData.aboutMe} (Age: {age})</p>}
          {currentPage === "projects" && <ProjectsPage data={portfolioData.projects} />}
          {currentPage === "education" && <p>Education section</p>}
          {currentPage === "location" && <p>Location section</p>}
        </div>
      </div>
    </div>
  );
};
export default App;