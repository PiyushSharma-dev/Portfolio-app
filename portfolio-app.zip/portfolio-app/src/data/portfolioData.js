const portfolioData = {
  name: "Piyush Sharma",
  tagline: "Optimizing Telecom Revenue & Data Integrity",
  title: "Telecom Mediation Professional",
  aboutMe: "Short intro about me...",
  projects: [],
  education: [],
  certifications: [],
  locations: [{ year: 2024, place: "Pune" }],
  experience: []
};
export default portfolioData;