import React from "react";
const HeaderButton = ({ icon, text, isActive, onClick }) => (
  <button
    className={\`flex items-center space-x-1 px-6 py-3 transition-all duration-300 focus:outline-none relative z-10 \${isActive
        ? 'bg-blue-600 text-white rounded-full shadow-sm'
        : 'bg-gray-700 text-gray-300 hover:bg-gray-600 rounded-full shadow-sm'}\`}
    onClick={onClick}
  >
    {icon}
    <span>{text}</span>
  </button>
);
export default HeaderButton;